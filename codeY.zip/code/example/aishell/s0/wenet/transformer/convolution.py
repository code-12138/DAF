# Copyright (c) 2020 Mobvoi Inc. (authors: Binbin Zhang, Di Wu)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# Modified from ESPnet(https://github.com/espnet/espnet)

"""ConvolutionModule definition."""

from typing import Tuple

import torch
from torch import nn
import functools
import torch
from torch import nn
import torch.nn.functional as F
from torch.nn.modules.conv import _ConvNd
from torch.nn.modules.utils import _pair
from torch.nn.parameter import Parameter
class Attention(nn.Module):
    def __init__(self,in_planes, C, r):#ratio = 1 // r = 1 // 16（默认）
        super().__init__()
        self.avgpool=nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Linear(C, C // r)
        self.sigmoid=nn.Sigmoid()
    def forward(self,x):
        # 将输入特征全局池化为 [N, C, 1, 1]
        att=self.avgpool(x)

        # 将特征转化为二维 [N, C]
        att=att.view(att.shape[0],-1) 
        # 使用 sigmoid 函数输出归一化到 [0,1] 区间
        return F.relu(self.fc(att))
class ODConv(nn.Module):
    def __init__(self,in_planes,out_planes,kernel_size,stride=1,padding=0,
                 groups=1,K=4,batchsize = 128):
        super().__init__()
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.K = K
        self.dim=80
        self.groups = groups
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.attention = Attention(in_planes=in_planes, C = in_planes, r = 16)
        self.weight = nn.Parameter(torch.randn(batchsize, K, self.out_planes, self.in_planes//self.groups,
             self.kernel_size),requires_grad=True)
        self.mtx = nn.Parameter(torch.randn(K, 1),requires_grad=True)
        self.fc1 = nn.Linear(in_planes // 16, kernel_size)
        self.fc2 = nn.Linear(in_planes // 16, in_planes * 1 // self.groups)
        self.fc3 = nn.Linear(in_planes // 16, out_planes * 1)
        self.fc4 = nn.Linear(in_planes // 16, K * 1)
        self.sigmoid = nn.Sigmoid()
        self.softmax = nn.Softmax(dim=-1)
        self.relu = nn.ReLU()
        self.fc_my = nn.Linear(80, 1)
        self.bn = nn.BatchNorm1d(out_planes)
        self.dropout = nn.Dropout(0.1)
        # self.W1=nn.Parameter(torch.randn(28, 4, 80, 1, 15),requires_grad=True)
        # self.W2=nn.Parameter(torch.randn(28, 4, 80, 1, 15),requires_grad=True)
        # self.W3=nn.Parameter(torch.randn(28, 4, 80, 1, 15),requires_grad=True)
        # self.W4=nn.Parameter(torch.randn(28, 4, 80, 1, 15),requires_grad=True)

    def forward(self,x):
        # 调用 attention 函数得到归一化的权重 [N, K]
        N,in_planels, dim = x.shape

        att=self.attention(x)#[N, Cin // 16]
        # print(att.shape)#torch.Size([28, 5])
        # exit()


        att1 = self.sigmoid(self.fc1(att))#[N, kernel_size * kernel_size]
        att1 = att1.reshape(att1.shape[0], self.kernel_size)#[N, kernel_size]


        att2 = self.sigmoid(self.fc2(att))#[N, in_planes]

        att3 = self.sigmoid(self.fc3(att))#[N, out_planes]

        att4 = self.softmax(self.fc4(att))#[N, K]
        Weight=Weight2=Weight3=Weight4=torch.ones(1)

        for i in range(x.shape[0]):
            if i == 0:
                Weight = torch.unsqueeze(self.weight[i, :, :, :, :] * att1[i, :], 0)
            else:

                Weight = torch.cat([Weight, torch.unsqueeze(self.weight[i, :, :, :, :] * att1[i, :], 0)], 0)        
        Weight = self.dropout(Weight)
        # print(Weight.shape)#torch.Size([28, 4, 80, 1, 15, 80])->torch.Size([28, 4, 80, 1, 15])
        # exit()


        for i in range(x.shape[0]):
            if i == 0:
                Weight2 = torch.unsqueeze(Weight[i, :, :, :, :] * att2[i, None, :, None], 0)
            else:
                Weight2 = torch.cat([Weight2, torch.unsqueeze(Weight[i, :, :, :, :] * att2[i, None, :, None], 0)], 0)
        Weight2 = self.dropout(Weight2)
        # print(Weight[i, :, :, :, :, :].shape)
        #print( att2[i, None, :, None, None].shape)
        # print(Weight2.shape)#([28, 4, 80, 1, 15])
        # exit()

        # print(Weight2[i, :, :, :, :].shape)
        # print(att3[i, None, :, None, None,  None].shape)
        # exit()
        for i in range(x.shape[0]):
            if i == 0:
                Weight3 = torch.unsqueeze(Weight2[i, :, :, :, :] * att3[i, None, :, None, None], 0)
            else:
                Weight3 = torch.cat([Weight3, torch.unsqueeze(Weight2[i, :, :, :, :] * att3[i, None, :, None, None], 0)], 0)

        Weight3 = self.dropout(Weight3)
        #print(att3[i, None, :, None, None, None].shape)
        # print(Weight3.shape)#torch.Size([28, 4, 80, 1, 15])
        # exit()

        for i in range(x.shape[0]):
            if i == 0:
                Weight4 = torch.unsqueeze(Weight3[i, :, :, :, :] * att4[i, :, None, None, None], 0)
            else:
                Weight4 = torch.cat([Weight4, torch.unsqueeze(Weight3[i, :, :, :, :] * att4[i, :, None, None, None], 0)], 0)
        Weight4 = self.dropout(Weight4)


        # print(att4[i, :, None, None, None, None].shape)
        # print(Weight4.shape)#torch.Size([28, 4, 80, 1, 15])
        # exit()
        Weight=Weight4
        Weight = torch.unsqueeze(Weight, 5)
        Weight = Weight.permute(0, 5, 2, 3, 4, 1)

        Weight = torch.matmul(Weight, self.mtx)
        # print(Weight4.shape)#torch.Size([28, 1, 80, 1, 15, 80, 1])->torch.Size([28, 1, 80, 1, 15, 1])
        # exit()
        x=x.view(1, -1, dim)
        Weight = Weight.view(
            N*self.out_planes, self.in_planes//self.groups,
            self.kernel_size)


        output=F.conv1d(x,weight=Weight,
                  stride=self.stride, padding=self.padding,
                  groups=self.groups*N)


     
        _, _, dim = output.shape
        output=output.view(N, self.out_planes,dim)
        output = self.relu(self.bn(output))
        return output
class ConvolutionModule(nn.Module):
    """ConvolutionModule in Conformer model."""
    def __init__(self,
                 channels: int,
                 kernel_size: int = 15,
                 activation: nn.Module = nn.ReLU(),
                 norm: str = "batch_norm",
                 causal: bool = False,
                 bias: bool = True):
        """Construct an ConvolutionModule object.
        Args:
            channels (int): The number of channels of conv layers.
            kernel_size (int): Kernel size of conv layers.
            causal (int): Whether use causal convolution or not
        """
        super().__init__()

        self.pointwise_conv1 = nn.Conv1d(
            channels,
            2 * channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=bias,
        )

        # self.lorder is used to distinguish if it's a causal convolution,
        # if self.lorder > 0: it's a causal convolution, the input will be
        #    padded with self.lorder frames on the left in forward.
        # else: it's a symmetrical convolution
        if causal:
            padding = 0
            self.lorder = kernel_size - 1
        else:
            # kernel_size should be an odd number for none causal convolution
            assert (kernel_size - 1) % 2 == 0
            padding = (kernel_size - 1) // 2
            self.lorder = 0
        self.depthwise_conv = nn.Conv1d(
            channels,
            channels,
            kernel_size,
            stride=1,
            padding=padding,
            groups=channels,
            bias=bias,
        )
        #self.odconv = ODConv(channels, channels, kernel_size,stride=1, groups=channels, padding=padding,K=4,batchsize=16)

        assert norm in ['batch_norm', 'layer_norm']
        if norm == "batch_norm":
            self.use_layer_norm = False
            self.norm = nn.BatchNorm1d(channels)
        else:
            self.use_layer_norm = True
            self.norm = nn.LayerNorm(channels)

        self.pointwise_conv2 = nn.Conv1d(
            channels,
            channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=bias,
        )
        self.activation = activation

    def forward(
        self,
        x: torch.Tensor,
        mask_pad: torch.Tensor = torch.ones((0, 0, 0), dtype=torch.bool),
        cache: torch.Tensor = torch.zeros((0, 0, 0)),
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute convolution module.
        Args:
            x (torch.Tensor): Input tensor (#batch, time, channels).
            mask_pad (torch.Tensor): used for batch padding (#batch, 1, time),
                (0, 0, 0) means fake mask.
            cache (torch.Tensor): left context cache, it is only
                used in causal convolution (#batch, channels, cache_t),
                (0, 0, 0) meas fake cache.
        Returns:
            torch.Tensor: Output tensor (#batch, time, channels).
        """
        # exchange the temporal dimension and the feature dimension
        x = x.transpose(1, 2)  # (#batch, channels, time)

        # mask batch padding
        if mask_pad.size(2) > 0:  # time > 0
            x.masked_fill_(~mask_pad, 0.0)

        if self.lorder > 0:
            if cache.size(2) == 0:  # cache_t == 0
                x = nn.functional.pad(x, (self.lorder, 0), 'constant', 0.0)
            else:
                assert cache.size(0) == x.size(0)  # equal batch
                assert cache.size(1) == x.size(1)  # equal channel
                x = torch.cat((cache, x), dim=2)
            assert (x.size(2) > self.lorder)
            new_cache = x[:, :, -self.lorder:]
        else:
            # It's better we just return None if no cache is required,
            # However, for JIT export, here we just fake one tensor instead of
            # None.
            new_cache = torch.zeros((0, 0, 0), dtype=x.dtype, device=x.device)

        # GLU mechanism
        x = self.pointwise_conv1(x)  # (batch, 2*channel, dim)
        x = nn.functional.glu(x, dim=1)  # (batch, channel, dim)

        # 1D Depthwise Conv
        x = self.depthwise_conv(x)
        #x = self.odconv(x)
        if self.use_layer_norm:
            x = x.transpose(1, 2)
        x = self.activation(self.norm(x))
        if self.use_layer_norm:
            x = x.transpose(1, 2)
        x = self.pointwise_conv2(x)
        # mask batch padding
        if mask_pad.size(2) > 0:  # time > 0
            x.masked_fill_(~mask_pad, 0.0)

        return x.transpose(1, 2), new_cache
